Genuine Reach — Interactive Guide
Mindful Earth · mindfulearth.eco

HOW TO USE:
1. Unzip this folder to your desktop
2. Open genuine-reach.html in Chrome or Firefox (not Safari)
3. Click any field to type your answers
4. Hit "Save progress" regularly  
5. Always open the SAME file in the SAME browser — your notes save there
6. File → Save As after each session for an extra backup

The photos/ folder must stay alongside the HTML file for images to load.

Questions? connect@mindfulearth.eco
